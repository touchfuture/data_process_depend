#ifndef _EMBED_TEXT_WM_H
#define _EMBED_TEXT_WM_H

#include <stdint.h>

/**
 * EmbedHiddenWMMemory 为暗水印 SDK libEmbedTextWM.so 提供的 API，用于对 BGR24 格式的视频帧添加暗水印信息。
 *
 * @param pFrame_data   ffmpeg 解析视频帧后按照 AV_PIX_FMT_BGR24 解析的 BGR 数据
 * @param linesize      解析后的 linesize ，也就是每行数据的宽度，一般为 width * 3，但不排除异常case
 * @param width         视频宽度
 * @param height        视频高度
 * @param wm_input      写入的水印内容， 应当是由 A~Z a~z 0~9 # _ 组成的字符串，其它字符会报错，长度限制在 1~62 之间。
 *                      图片尺寸越小，可写入的水印内容越少。没有具体的计算公式。
 * @param method        "text_adapt"
 * @param strength      水印强度 1、2、3，值越大，水印强度越高
 */
int EmbedHiddenWMMemory(uint8_t *pFrame_data, int linesize, int width, int height,
                        const char *wm_input, const char *method, char *out_message, int strength);

#endif // _EMBED_TEXT_WM_H
