#include "EmbedTextWM.h"

int EmbedHiddenWMMemory(uint8_t *pFrame_data, int linesize, int width, int height,
                        const char *wm_input, const char *method, char *out_message, int strength) {
  return -1;
}
